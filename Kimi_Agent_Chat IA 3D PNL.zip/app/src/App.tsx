import { useState, useEffect, useRef, useMemo } from 'react'
import { Canvas, useFrame } from '@react-three/fiber'
import { 
  Environment, 
  PerspectiveCamera, 
  useTexture, 
  Float,
  Stars
} from '@react-three/drei'
import { EffectComposer, Bloom, ChromaticAberration, Vignette } from '@react-three/postprocessing'
import * as THREE from 'three'
import './App.css'

// Types
interface Message {
  id: string
  agent: 'N.O.S' | 'ADEMO' | 'MONK'
  content: string
  timestamp: Date
  type: 'status' | 'analysis' | 'action' | 'discovery'
}

interface Agent {
  id: string
  name: string
  role: string
  image: string
  color: string
  position: [number, number, number]
}

// Conversation data from NOMOS42
const conversationData: Message[] = [
  {
    id: '1',
    agent: 'N.O.S',
    content: 'Status: Gen 0 | Brier 1.0000 | ROI 0.0% | 0 feats | Pop 0',
    timestamp: new Date(),
    type: 'status'
  },
  {
    id: '2',
    agent: 'ADEMO',
    content: 'Candidates: ? | Mutation: 0.03 | Stag: 0 | Models: 5/10',
    timestamp: new Date(),
    type: 'status'
  },
  {
    id: '3',
    agent: 'MONK',
    content: 'Diagnosis: S10 is stuck in STARTING state, indicating initialization failure; resetting population may kickstart evolution.',
    timestamp: new Date(),
    type: 'analysis'
  },
  {
    id: '4',
    agent: 'MONK',
    content: 'AUTO-FIX applied: population reset',
    timestamp: new Date(),
    type: 'action'
  },
  {
    id: '5',
    agent: 'ADEMO',
    content: 'Research cycle: deep-diving "rest_schedule" (B2B, rest days, travel fatigue).',
    timestamp: new Date(),
    type: 'discovery'
  },
  {
    id: '6',
    agent: 'N.O.S',
    content: 'Eval: avg Brier 1.0000, trend 0.0000, 4 obs. Problems: none detected',
    timestamp: new Date(),
    type: 'analysis'
  },
  {
    id: '7',
    agent: 'ADEMO',
    content: 'DISCOVERED: "rest_schedule" — low power, impact: rest_schedule features for the NBA Quant model',
    timestamp: new Date(),
    type: 'discovery'
  },
  {
    id: '8',
    agent: 'ADEMO',
    content: 'DISCOVERED: "rest_travel_fatigue_index" — captures joint effect of travel and rest',
    timestamp: new Date(),
    type: 'discovery'
  },
  {
    id: '9',
    agent: 'ADEMO',
    content: 'Research complete. +4 new. Total: 9 features catalogued. 9 untested.',
    timestamp: new Date(),
    type: 'status'
  },
  {
    id: '10',
    agent: 'N.O.S',
    content: 'Tactical assessment: The model is outputting the opposite of the true label (Brier ≈ 1.0), indicating a systematic data-pipeline bug.',
    timestamp: new Date(),
    type: 'analysis'
  }
]

const agents: Agent[] = [
  {
    id: 'nos',
    name: 'N.O.S',
    role: 'Strategic Commander',
    image: '/nos-character.jpg',
    color: '#00d4ff',
    position: [-3, 0, 0]
  },
  {
    id: 'ademo',
    name: 'ADEMO',
    role: 'Research & Execution',
    image: '/ademo-character.jpg',
    color: '#ff6b35',
    position: [0, 0, 0]
  },
  {
    id: 'monk',
    name: 'MONK',
    role: 'Evolution Engine',
    image: '/monk-character.jpg',
    color: '#00ff88',
    position: [3, 0, 0]
  }
]

// 3D Components
function CharacterCard({ agent, isActive }: { agent: Agent; isActive: boolean }) {
  const texture = useTexture(agent.image)
  const meshRef = useRef<THREE.Mesh>(null)
  const glowRef = useRef<THREE.Mesh>(null)
  
  useFrame((state) => {
    if (meshRef.current) {
      meshRef.current.rotation.y = Math.sin(state.clock.elapsedTime * 0.5) * 0.05
      meshRef.current.position.y = Math.sin(state.clock.elapsedTime * 1.5) * 0.05
    }
    if (glowRef.current && isActive) {
      const scale = 1 + Math.sin(state.clock.elapsedTime * 3) * 0.02
      glowRef.current.scale.setScalar(scale)
    }
  })

  return (
    <group position={agent.position}>
      {/* Glow effect when active */}
      {isActive && (
        <mesh ref={glowRef} position={[0, 0, -0.1]}>
          <planeGeometry args={[2.2, 3.8]} />
          <meshBasicMaterial 
            color={agent.color} 
            transparent 
            opacity={0.3}
            side={THREE.DoubleSide}
          />
        </mesh>
      )}
      
      {/* Character image plane */}
      <mesh ref={meshRef}>
        <planeGeometry args={[2, 3.5]} />
        <meshBasicMaterial map={texture} transparent />
      </mesh>
      
      {/* Holographic frame */}
      <mesh position={[0, 0, -0.05]}>
        <planeGeometry args={[2.1, 3.6]} />
        <meshBasicMaterial color={agent.color} transparent opacity={0.1} wireframe />
      </mesh>
      
      {/* Name tag */}
      <group position={[0, -2.2, 0.1]}>
        <mesh>
          <planeGeometry args={[1.8, 0.4]} />
          <meshBasicMaterial color="#000000" transparent opacity={0.8} />
        </mesh>
      </group>
    </group>
  )
}

function ParticleField() {
  const pointsRef = useRef<THREE.Points>(null)
  const particleCount = 500
  
  const positions = useMemo(() => {
    const pos = new Float32Array(particleCount * 3)
    for (let i = 0; i < particleCount; i++) {
      pos[i * 3] = (Math.random() - 0.5) * 20
      pos[i * 3 + 1] = (Math.random() - 0.5) * 10
      pos[i * 3 + 2] = (Math.random() - 0.5) * 10
    }
    return pos
  }, [])
  
  useFrame((state) => {
    if (pointsRef.current) {
      pointsRef.current.rotation.y = state.clock.elapsedTime * 0.05
    }
  })
  
  return (
    <points ref={pointsRef}>
      <bufferGeometry>
        <bufferAttribute
          attach="attributes-position"
          args={[positions, 3]}
        />
      </bufferGeometry>
      <pointsMaterial size={0.02} color="#00d4ff" transparent opacity={0.6} />
    </points>
  )
}

function HolographicGrid() {
  const gridRef = useRef<THREE.GridHelper>(null)
  
  useFrame((state) => {
    if (gridRef.current) {
      gridRef.current.position.y = -2 + Math.sin(state.clock.elapsedTime * 0.5) * 0.2
    }
  })
  
  return (
    <>
      <gridHelper 
        ref={gridRef}
        args={[20, 20, '#00d4ff', '#1a1a2e']} 
        position={[0, -2, 0]}
      />
      <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, -2.1, 0]}>
        <planeGeometry args={[20, 20]} />
        <meshBasicMaterial color="#0a0a1a" transparent opacity={0.8} />
      </mesh>
    </>
  )
}

function Scene({ activeAgent }: { activeAgent: string | null }) {
  return (
    <>
      <PerspectiveCamera makeDefault position={[0, 0, 8]} fov={50} />
      <ambientLight intensity={0.3} />
      <pointLight position={[10, 10, 10]} intensity={0.5} color="#00d4ff" />
      <pointLight position={[-10, 10, 10]} intensity={0.3} color="#ff6b35" />
      <pointLight position={[0, -10, 5]} intensity={0.2} color="#00ff88" />
      
      <Environment preset="city" />
      
      {/* Background */}
      <Stars radius={100} depth={50} count={5000} factor={4} saturation={0} fade speed={1} />
      
      {/* Characters */}
      {agents.map((agent) => (
        <Float key={agent.id} speed={2} rotationIntensity={0.1} floatIntensity={0.2}>
          <CharacterCard 
            agent={agent} 
            isActive={activeAgent === agent.id}
          />
        </Float>
      ))}
      
      {/* Effects */}
      <ParticleField />
      <HolographicGrid />
      
      {/* Post-processing */}
      <EffectComposer>
        <Bloom intensity={0.5} luminanceThreshold={0.2} luminanceSmoothing={0.9} />
        <ChromaticAberration offset={[0.001, 0.001]} />
        <Vignette eskil={false} offset={0.1} darkness={0.5} />
      </EffectComposer>
      
      {/* Fog */}
      <fog attach="fog" args={['#0a0a1a', 5, 20]} />
    </>
  )
}

// UI Components
function DialogueBox({ message, isVisible }: { message: Message | null; isVisible: boolean }) {
  if (!message || !isVisible) return null
  
  const agent = agents.find(a => a.name === message.agent)
  const getTypeColor = (type: string) => {
    switch (type) {
      case 'status': return '#00d4ff'
      case 'analysis': return '#ff6b35'
      case 'action': return '#00ff88'
      case 'discovery': return '#ff00ff'
      default: return '#ffffff'
    }
  }
  
  return (
    <div className="dialogue-box" style={{ borderColor: agent?.color || '#fff' }}>
      <div className="dialogue-header" style={{ backgroundColor: agent?.color || '#fff' }}>
        <span className="agent-name">{message.agent}</span>
        <span className="message-type" style={{ color: getTypeColor(message.type) }}>
          {message.type.toUpperCase()}
        </span>
      </div>
      <div className="dialogue-content">
        <p className="typing-text">{message.content}</p>
      </div>
      <div className="dialogue-footer">
        <div className="audio-wave">
          {[...Array(8)].map((_, i) => (
            <span key={i} className="wave-bar" style={{ animationDelay: `${i * 0.1}s` }} />
          ))}
        </div>
      </div>
    </div>
  )
}

function StatusPanel({ metrics }: { metrics: any }) {
  return (
    <div className="status-panel">
      <h3>NOMOS42 METRICS</h3>
      <div className="metrics-grid">
        <div className="metric">
          <span className="metric-label">BRIER</span>
          <span className="metric-value">{metrics.brier || '—'}</span>
        </div>
        <div className="metric">
          <span className="metric-label">ACCURACY</span>
          <span className="metric-value">{metrics.accuracy || '0.0%'}</span>
        </div>
        <div className="metric">
          <span className="metric-label">ROI</span>
          <span className="metric-value">{metrics.roi || '—'}</span>
        </div>
        <div className="metric">
          <span className="metric-label">FEATURES</span>
          <span className="metric-value">{metrics.features || '0'}</span>
        </div>
        <div className="metric">
          <span className="metric-label">GENERATION</span>
          <span className="metric-value">{metrics.generation || '0'}</span>
        </div>
        <div className="metric">
          <span className="metric-label">POPULATION</span>
          <span className="metric-value">{metrics.population || '0'}</span>
        </div>
      </div>
    </div>
  )
}

function AgentInfo({ agent }: { agent: Agent }) {
  return (
    <div className="agent-info" style={{ borderColor: agent.color }}>
      <div className="agent-avatar" style={{ backgroundImage: `url(${agent.image})` }} />
      <div className="agent-details">
        <h4 style={{ color: agent.color }}>{agent.name}</h4>
        <p>{agent.role}</p>
      </div>
    </div>
  )
}

// Main App
function App() {
  const [currentMessageIndex, setCurrentMessageIndex] = useState(0)
  const [isPlaying, setIsPlaying] = useState(true)
  const [showDialogue, setShowDialogue] = useState(true)
  const [activeAgent, setActiveAgent] = useState<string | null>(null)
  
  const metrics = {
    brier: '1.0000',
    accuracy: '0.0%',
    roi: '—',
    features: '9',
    generation: '0',
    population: '0'
  }
  
  useEffect(() => {
    if (!isPlaying) return
    
    const interval = setInterval(() => {
      setCurrentMessageIndex((prev) => {
        const next = (prev + 1) % conversationData.length
        const message = conversationData[next]
        const agent = agents.find(a => a.name === message.agent)
        setActiveAgent(agent?.id || null)
        return next
      })
    }, 4000)
    
    return () => clearInterval(interval)
  }, [isPlaying])
  
  const currentMessage = conversationData[currentMessageIndex]
  
  return (
    <div className="app-container">
      {/* 3D Scene */}
      <div className="scene-container">
        <Canvas>
          <Scene activeAgent={activeAgent} />
        </Canvas>
      </div>
      
      {/* UI Overlay */}
      <div className="ui-overlay">
        {/* Header */}
        <header className="main-header">
          <h1>NOMOS42</h1>
          <div className="header-subtitle">
            <span className="qlf-badge">QLF</span>
            <span>AI AGENTS CONVERSATION</span>
          </div>
        </header>
        
        {/* Left Panel - Agent Info */}
        <div className="left-panel">
          {agents.map(agent => (
            <AgentInfo key={agent.id} agent={agent} />
          ))}
        </div>
        
        {/* Right Panel - Status */}
        <div className="right-panel">
          <StatusPanel metrics={metrics} />
        </div>
        
        {/* Bottom - Dialogue */}
        <div className="bottom-panel">
          <DialogueBox message={currentMessage} isVisible={showDialogue} />
        </div>
        
        {/* Controls */}
        <div className="controls">
          <button 
            className="control-btn"
            onClick={() => setIsPlaying(!isPlaying)}
          >
            {isPlaying ? '⏸' : '▶'}
          </button>
          <button 
            className="control-btn"
            onClick={() => setShowDialogue(!showDialogue)}
          >
            💬
          </button>
        </div>
        
        {/* Progress indicator */}
        <div className="progress-bar">
          {conversationData.map((_, index) => (
            <div 
              key={index}
              className={`progress-dot ${index === currentMessageIndex ? 'active' : ''}`}
              onClick={() => setCurrentMessageIndex(index)}
            />
          ))}
        </div>
      </div>
    </div>
  )
}

export default App
