import { useState, useEffect, useRef, useMemo, useCallback } from 'react'
import { Canvas, useFrame } from '@react-three/fiber'
import { 
  Environment, 
  PerspectiveCamera, 
  useTexture, 
  Float,
  Stars,
  Text
} from '@react-three/drei'
import { EffectComposer, Bloom, ChromaticAberration, Vignette } from '@react-three/postprocessing'
import * as THREE from 'three'
import './App.css'
import type { Message, Agent, Metrics } from './types'
import { useLiveData } from './hooks/useLiveData'

// ============================================
// CONFIGURATION - MODIFIE CETTE PARTIE
// ============================================

/** 
 * MODE DE CONNEXION AUX DONNÉES LIVE
 * 
 * 'static'  = Utilise les données en dur ci-dessous (démo)
 * 'websocket' = Connexion WebSocket temps réel
 * 'polling' = Polling API toutes les X secondes
 * 'json' = Charge depuis public/live-data.json
 */
const DATA_MODE: 'static' | 'websocket' | 'polling' | 'json' = 'static'

/** URL de ton endpoint (si websocket/polling) */
const LIVE_DATA_URL = 'wss://nomos42-worker.hf.space/ws'
// ou: const LIVE_DATA_URL = 'https://nomos42-worker.hf.space/api/messages'

/** Intervalle de polling en ms (si mode='polling') */
const POLLING_INTERVAL = 2000

// ============================================
// DONNÉES STATIQUES (MODE DEMO)
// ============================================

const STATIC_CONVERSATION: Message[] = [
  {
    id: '1',
    agent: 'N.O.S',
    content: 'Status: Gen 0 | Brier 1.0000 | ROI 0.0% | 0 feats | Pop 0',
    timestamp: new Date().toISOString(),
    type: 'status'
  },
  {
    id: '2',
    agent: 'ADEMO',
    content: 'Candidates: ? | Mutation: 0.03 | Stag: 0 | Models: 5/10',
    timestamp: new Date().toISOString(),
    type: 'status'
  },
  {
    id: '3',
    agent: 'MONK',
    content: 'Diagnosis: S10 is stuck in STARTING state, indicating initialization failure; resetting population may kickstart evolution.',
    timestamp: new Date().toISOString(),
    type: 'analysis'
  },
  {
    id: '4',
    agent: 'MONK',
    content: 'AUTO-FIX applied: population reset',
    timestamp: new Date().toISOString(),
    type: 'action'
  },
  {
    id: '5',
    agent: 'ADEMO',
    content: 'Research cycle: deep-diving "rest_schedule" (B2B, rest days, travel fatigue).',
    timestamp: new Date().toISOString(),
    type: 'discovery'
  },
  {
    id: '6',
    agent: 'N.O.S',
    content: 'Eval: avg Brier 1.0000, trend 0.0000, 4 obs. Problems: none detected',
    timestamp: new Date().toISOString(),
    type: 'analysis'
  },
  {
    id: '7',
    agent: 'ADEMO',
    content: 'DISCOVERED: "rest_schedule" — low power, impact: rest_schedule features for the NBA Quant model',
    timestamp: new Date().toISOString(),
    type: 'discovery'
  },
  {
    id: '8',
    agent: 'ADEMO',
    content: 'DISCOVERED: "rest_travel_fatigue_index" — captures joint effect of travel and rest',
    timestamp: new Date().toISOString(),
    type: 'discovery'
  },
  {
    id: '9',
    agent: 'ADEMO',
    content: 'Research complete. +4 new. Total: 9 features catalogued. 9 untested.',
    timestamp: new Date().toISOString(),
    type: 'status'
  },
  {
    id: '10',
    agent: 'N.O.S',
    content: 'Tactical assessment: The model is outputting the opposite of the true label (Brier ≈ 1.0), indicating a systematic data-pipeline bug.',
    timestamp: new Date().toISOString(),
    type: 'analysis'
  }
]

// ============================================
// CONFIGURATION DES AGENTS
// ============================================

const AGENTS: Agent[] = [
  {
    id: 'nos',
    name: 'N.O.S',
    role: 'Strategic Commander',
    image: '/nos-character.jpg',
    color: '#c9a227', // Or sicilien (Deux Frères)
    position: [-3.5, 0, 0]
  },
  {
    id: 'ademo',
    name: 'ADEMO',
    role: 'Research & Execution',
    image: '/ademo-character.jpg',
    color: '#ff6b35', // Orange PNL
    position: [0, 0, 0]
  },
  {
    id: 'monk',
    name: 'MONK',
    role: 'Evolution Engine',
    image: '/monk-character.jpg',
    color: '#00ff88', // Vert cyber
    position: [3.5, 0, 0]
  }
]

// ============================================
// COMPOSANTS 3D
// ============================================

function CharacterCard({ agent, isActive, isSpeaking }: { 
  agent: Agent
  isActive: boolean
  isSpeaking: boolean
}) {
  const texture = useTexture(agent.image)
  const meshRef = useRef<THREE.Mesh>(null)
  const glowRef = useRef<THREE.Mesh>(null)
  const ringRef = useRef<THREE.Mesh>(null)
  
  useFrame((state) => {
    const time = state.clock.elapsedTime
    
    if (meshRef.current) {
      // Animation de respiration
      meshRef.current.position.y = Math.sin(time * 1.5) * 0.05
      // Légère rotation
      meshRef.current.rotation.y = Math.sin(time * 0.5) * 0.03
    }
    
    // Glow pulsant quand actif
    if (glowRef.current && isActive) {
      const scale = 1 + Math.sin(time * 4) * 0.03
      glowRef.current.scale.setScalar(scale)
    }
    
    // Anneau qui tourne quand l'agent parle
    if (ringRef.current && isSpeaking) {
      ringRef.current.rotation.z = time * 2
      ringRef.current.visible = true
    } else if (ringRef.current) {
      ringRef.current.visible = false
    }
  })

  return (
    <group position={agent.position}>
      {/* Glow background quand actif */}
      {isActive && (
        <mesh ref={glowRef} position={[0, 0, -0.15]}>
          <planeGeometry args={[2.4, 4]} />
          <meshBasicMaterial 
            color={agent.color} 
            transparent 
            opacity={0.25}
            side={THREE.DoubleSide}
          />
        </mesh>
      )}
      
      {/* Anneau de parole */}
      <mesh ref={ringRef} position={[0, -2.5, 0.2]}>
        <ringGeometry args={[0.8, 1, 32]} />
        <meshBasicMaterial color={agent.color} transparent opacity={0.8} />
      </mesh>
      
      {/* Image du personnage */}
      <mesh ref={meshRef}>
        <planeGeometry args={[2, 3.5]} />
        <meshBasicMaterial map={texture} transparent />
      </mesh>
      
      {/* Cadre holographique */}
      <mesh position={[0, 0, -0.08]}>
        <planeGeometry args={[2.15, 3.65]} />
        <meshBasicMaterial 
          color={agent.color} 
          transparent 
          opacity={isActive ? 0.3 : 0.1} 
          wireframe 
        />
      </mesh>
      
      {/* Nom sous le personnage */}
      <Text
        position={[0, -2.1, 0.1]}
        fontSize={0.25}
        color={agent.color}
        anchorX="center"
        anchorY="middle"
        font="/fonts/Orbitron-Bold.ttf"
      >
        {agent.name}
      </Text>
      
      {/* Role */}
      <Text
        position={[0, -2.4, 0.1]}
        fontSize={0.12}
        color="rgba(255,255,255,0.6)"
        anchorX="center"
        anchorY="middle"
      >
        {agent.role.toUpperCase()}
      </Text>
    </group>
  )
}

function ParticleField() {
  const pointsRef = useRef<THREE.Points>(null)
  const particleCount = 800
  
  const positions = useMemo(() => {
    const pos = new Float32Array(particleCount * 3)
    for (let i = 0; i < particleCount; i++) {
      pos[i * 3] = (Math.random() - 0.5) * 25
      pos[i * 3 + 1] = (Math.random() - 0.5) * 15
      pos[i * 3 + 2] = (Math.random() - 0.5) * 15
    }
    return pos
  }, [])
  
  useFrame((state) => {
    if (pointsRef.current) {
      pointsRef.current.rotation.y = state.clock.elapsedTime * 0.02
    }
  })
  
  return (
    <points ref={pointsRef}>
      <bufferGeometry>
        <bufferAttribute
          attach="attributes-position"
          args={[positions, 3]}
        />
      </bufferGeometry>
      <pointsMaterial 
        size={0.025} 
        color="#c9a227" 
        transparent 
        opacity={0.5}
        sizeAttenuation
      />
    </points>
  )
}

function HolographicGrid() {
  const gridRef = useRef<THREE.GridHelper>(null)
  
  useFrame((state) => {
    if (gridRef.current) {
      gridRef.current.position.y = -2.5 + Math.sin(state.clock.elapsedTime * 0.3) * 0.15
    }
  })
  
  return (
    <>
      <gridHelper 
        ref={gridRef}
        args={[25, 25, '#c9a227', '#2a2520']} 
        position={[0, -2.5, 0]}
      />
      <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, -2.6, 0]}>
        <planeGeometry args={[25, 25]} />
        <meshBasicMaterial color="#0a0a1a" transparent opacity={0.85} />
      </mesh>
    </>
  )
}

function BackgroundImage() {
  const texture = useTexture('/environment-bg.jpg')
  
  return (
    <mesh position={[0, 0, -8]} scale={[16, 9, 1]}>
      <planeGeometry args={[1, 1]} />
      <meshBasicMaterial map={texture} transparent opacity={0.4} />
    </mesh>
  )
}

function Scene({ activeAgent, speakingAgent }: { 
  activeAgent: string | null
  speakingAgent: string | null
}) {
  return (
    <>
      <PerspectiveCamera makeDefault position={[0, 0.5, 9]} fov={45} />
      
      {/* Lumières */}
      <ambientLight intensity={0.4} />
      <pointLight position={[10, 8, 8]} intensity={0.6} color="#c9a227" />
      <pointLight position={[-10, 8, 8]} intensity={0.4} color="#ff6b35" />
      <pointLight position={[0, -8, 5]} intensity={0.3} color="#00ff88" />
      <spotLight 
        position={[0, 10, 0]} 
        angle={0.5} 
        penumbra={0.5} 
        intensity={0.5}
        color="#ffffff"
      />
      
      {/* Environnement */}
      <Environment preset="sunset" />
      
      {/* Background */}
      <BackgroundImage />
      <Stars radius={80} depth={40} count={3000} factor={3} saturation={0.3} fade speed={0.5} />
      
      {/* Personnages */}
      {AGENTS.map((agent) => (
        <Float 
          key={agent.id} 
          speed={1.5} 
          rotationIntensity={0.08} 
          floatIntensity={0.15}
        >
          <CharacterCard 
            agent={agent} 
            isActive={activeAgent === agent.id}
            isSpeaking={speakingAgent === agent.id}
          />
        </Float>
      ))}
      
      {/* Effets */}
      <ParticleField />
      <HolographicGrid />
      
      {/* Post-processing */}
      <EffectComposer>
        <Bloom 
          intensity={0.6} 
          luminanceThreshold={0.25} 
          luminanceSmoothing={0.85}
          mipmapBlur
        />
        <ChromaticAberration offset={[0.0015, 0.0015]} />
        <Vignette eskil={false} offset={0.15} darkness={0.6} />
      </EffectComposer>
      
      {/* Fog atmosphérique */}
      <fog attach="fog" args={['#1a1510', 8, 25]} />
    </>
  )
}

// ============================================
// COMPOSANTS UI
// ============================================

function DialogueBox({ message, isVisible }: { message: Message | null; isVisible: boolean }) {
  if (!message || !isVisible) return null
  
  const agent = AGENTS.find(a => a.name === message.agent)
  
  const getTypeColor = (type: Message['type']) => {
    switch (type) {
      case 'status': return '#00d4ff'
      case 'analysis': return '#ff6b35'
      case 'action': return '#00ff88'
      case 'discovery': return '#ff00ff'
      case 'error': return '#ff3333'
      default: return '#ffffff'
    }
  }
  
  const getTypeIcon = (type: Message['type']) => {
    switch (type) {
      case 'status': return '📊'
      case 'analysis': return '🔍'
      case 'action': return '⚡'
      case 'discovery': return '💡'
      case 'error': return '⚠️'
      default: return '💬'
    }
  }
  
  return (
    <div className="dialogue-box" style={{ borderColor: agent?.color || '#fff' }}>
      <div className="dialogue-header" style={{ background: `linear-gradient(90deg, ${agent?.color}40, transparent)` }}>
        <div className="dialogue-agent">
          <span className="agent-avatar-small" style={{ backgroundImage: `url(${agent?.image})` }} />
          <span className="agent-name" style={{ color: agent?.color }}>{message.agent}</span>
        </div>
        <span className="message-type" style={{ color: getTypeColor(message.type) }}>
          {getTypeIcon(message.type)} {message.type.toUpperCase()}
        </span>
      </div>
      <div className="dialogue-content">
        <p className="typing-text">{message.content}</p>
      </div>
      <div className="dialogue-footer">
        <div className="audio-wave">
          {[...Array(10)].map((_, i) => (
            <span 
              key={i} 
              className="wave-bar" 
              style={{ 
                animationDelay: `${i * 0.08}s`,
                background: `linear-gradient(to top, ${agent?.color}, transparent)`
              }} 
            />
          ))}
        </div>
        <span className="timestamp">
          {new Date(message.timestamp).toLocaleTimeString('fr-FR', { 
            hour: '2-digit', 
            minute: '2-digit',
            second: '2-digit'
          })}
        </span>
      </div>
    </div>
  )
}

function StatusPanel({ metrics }: { metrics: Metrics }) {
  return (
    <div className="status-panel">
      <h3>
        <span className="status-icon">◈</span>
        NOMOS42 METRICS
        <span className="status-icon">◈</span>
      </h3>
      <div className="metrics-grid">
        <div className="metric">
          <span className="metric-label">BRIER</span>
          <span className="metric-value" style={{ color: '#00d4ff' }}>{metrics.brier}</span>
        </div>
        <div className="metric">
          <span className="metric-label">ACCURACY</span>
          <span className="metric-value" style={{ color: '#ff6b35' }}>{metrics.accuracy}</span>
        </div>
        <div className="metric">
          <span className="metric-label">ROI</span>
          <span className="metric-value" style={{ color: '#00ff88' }}>{metrics.roi}</span>
        </div>
        <div className="metric">
          <span className="metric-label">FEATURES</span>
          <span className="metric-value">{metrics.features}</span>
        </div>
        <div className="metric">
          <span className="metric-label">GENERATION</span>
          <span className="metric-value">{metrics.generation}</span>
        </div>
        <div className="metric">
          <span className="metric-label">POPULATION</span>
          <span className="metric-value">{metrics.population}</span>
        </div>
      </div>
    </div>
  )
}

function AgentInfo({ agent, isActive }: { agent: Agent; isActive: boolean }) {
  return (
    <div 
      className={`agent-info ${isActive ? 'active' : ''}`} 
      style={{ borderColor: agent.color }}
    >
      <div 
        className="agent-avatar" 
        style={{ 
          backgroundImage: `url(${agent.image})`,
          boxShadow: isActive ? `0 0 20px ${agent.color}` : 'none'
        }} 
      />
      <div className="agent-details">
        <h4 style={{ color: agent.color }}>{agent.name}</h4>
        <p>{agent.role}</p>
        {isActive && <span className="active-indicator">● EN LIGNE</span>}
      </div>
    </div>
  )
}

function ConnectionStatus({ isConnected, mode }: { isConnected: boolean; mode: string }) {
  return (
    <div className={`connection-status ${isConnected ? 'connected' : 'disconnected'}`}>
      <span className="status-dot" />
      <span>{isConnected ? `LIVE (${mode})` : 'DÉCONNECTÉ'}</span>
    </div>
  )
}

// ============================================
// APP PRINCIPAL
// ============================================

function App() {
  // État pour mode statique (démo)
  const [staticIndex, setStaticIndex] = useState(0)
  const [isPlaying, setIsPlaying] = useState(true)
  const [showDialogue, setShowDialogue] = useState(true)
  const [activeAgent, setActiveAgent] = useState<string | null>(null)
  const [speakingAgent, setSpeakingAgent] = useState<string | null>(null)
  
  // Hook pour données live (si mode != 'static')
  const { 
    messages: liveMessages, 
    isConnected,
    error 
  } = useLiveData({
    url: DATA_MODE !== 'static' ? LIVE_DATA_URL : undefined,
    mode: DATA_MODE === 'static' ? 'json' : DATA_MODE,
    pollingInterval: POLLING_INTERVAL
  })
  
  // Choisir les messages à afficher
  const messages = DATA_MODE === 'static' ? STATIC_CONVERSATION : liveMessages
  const currentMessage = messages[DATA_MODE === 'static' ? staticIndex : messages.length - 1] || null
  
  // Métriques
  const [metrics, setMetrics] = useState<Metrics>({
    brier: '1.0000',
    accuracy: '0.0%',
    roi: '—',
    features: '9',
    generation: '0',
    population: '0'
  })
  
  // Animation mode statique
  useEffect(() => {
    if (DATA_MODE !== 'static' || !isPlaying) return
    
    const interval = setInterval(() => {
      setStaticIndex(prev => {
        const next = (prev + 1) % STATIC_CONVERSATION.length
        const message = STATIC_CONVERSATION[next]
        const agent = AGENTS.find(a => a.name === message.agent)
        setActiveAgent(agent?.id || null)
        setSpeakingAgent(agent?.id || null)
        
        // Reset speaking après 2s
        setTimeout(() => setSpeakingAgent(null), 2000)
        
        return next
      })
    }, 5000)
    
    return () => clearInterval(interval)
  }, [isPlaying])
  
  // Mettre à jour l'agent actif quand message change (mode live)
  useEffect(() => {
    if (DATA_MODE === 'static') return
    if (currentMessage) {
      const agent = AGENTS.find(a => a.name === currentMessage.agent)
      setActiveAgent(agent?.id || null)
      setSpeakingAgent(agent?.id || null)
      setTimeout(() => setSpeakingAgent(null), 2000)
    }
  }, [currentMessage])
  
  // Navigation manuelle
  const goToMessage = useCallback((index: number) => {
    if (DATA_MODE !== 'static') return
    setStaticIndex(index)
    const message = STATIC_CONVERSATION[index]
    const agent = AGENTS.find(a => a.name === message.agent)
    setActiveAgent(agent?.id || null)
  }, [])
  
  return (
    <div className="app-container">
      {/* Scène 3D */}
      <div className="scene-container">
        <Canvas dpr={[1, 2]} gl={{ antialias: true, alpha: true }}>
          <Scene activeAgent={activeAgent} speakingAgent={speakingAgent} />
        </Canvas>
      </div>
      
      {/* UI Overlay */}
      <div className="ui-overlay">
        {/* Header */}
        <header className="main-header">
          <h1>NOMOS42</h1>
          <div className="header-subtitle">
            <span className="qlf-badge">QLF</span>
            <span>AI AGENTS CONVERSATION</span>
            <ConnectionStatus isConnected={DATA_MODE === 'static' ? true : isConnected} mode={DATA_MODE} />
          </div>
        </header>
        
        {/* Panel gauche - Agents */}
        <div className="left-panel">
          {AGENTS.map(agent => (
            <AgentInfo 
              key={agent.id} 
              agent={agent} 
              isActive={activeAgent === agent.id}
            />
          ))}
        </div>
        
        {/* Panel droit - Métriques */}
        <div className="right-panel">
          <StatusPanel metrics={metrics} />
        </div>
        
        {/* Panel bas - Dialogue */}
        <div className="bottom-panel">
          <DialogueBox message={currentMessage} isVisible={showDialogue} />
        </div>
        
        {/* Contrôles */}
        <div className="controls">
          <button 
            className="control-btn"
            onClick={() => setIsPlaying(!isPlaying)}
            title={isPlaying ? 'Pause' : 'Play'}
          >
            {isPlaying ? '⏸' : '▶'}
          </button>
          <button 
            className="control-btn"
            onClick={() => setShowDialogue(!showDialogue)}
            title="Toggle dialogue"
          >
            💬
          </button>
          <button 
            className="control-btn"
            onClick={() => goToMessage(0)}
            title="Restart"
          >
            ↺
          </button>
        </div>
        
        {/* Barre de progression (mode statique uniquement) */}
        {DATA_MODE === 'static' && (
          <div className="progress-bar">
            {STATIC_CONVERSATION.map((_, index) => (
              <div 
                key={index}
                className={`progress-dot ${index === staticIndex ? 'active' : ''} ${index < staticIndex ? 'passed' : ''}`}
                onClick={() => goToMessage(index)}
                title={`Message ${index + 1}`}
              />
            ))}
          </div>
        )}
        
        {/* Error display */}
        {error && (
          <div className="error-toast">
            ⚠️ {error}
          </div>
        )}
      </div>
    </div>
  )
}

export default App
