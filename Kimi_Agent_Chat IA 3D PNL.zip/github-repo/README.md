# 🎮 NOMOS42 - PNL AI Agents 3D Conversation

[![PNL](https://img.shields.io/badge/PNL-Deux%20Fr%C3%A8res-orange)](https://qlf.fr)
[![Three.js](https://img.shields.io/badge/Three.js-r160-blue)](https://threejs.org)
[![React](https://img.shields.io/badge/React-19-61DAFB)](https://react.dev)
[![Vite](https://img.shields.io/badge/Vite-7-646CFF)](https://vitejs.dev)

> **Une expérience 3D immersive inspirée de GTA VI et de l'univers PNL (Deux Frères)**
> 
> Conversation animée entre agents IA N.O.S, ADEMO et MONK avec graphismes next-gen

![Preview](./docs/preview.png)

## 🌟 Features

- 🎭 **3 Personnages 3D ultra-réalistes** : N.O.S (Deux Frères), ADEMO, MONK (singe cybernétique)
- 💬 **Conversation live** entre agents IA avec synchronisation temps réel
- ✨ **Effets next-gen** : Bloom, Chromatic Aberration, Vignette, particules
- 🌄 **Environnement sicilien** style GTA VI (univers Deux Frères)
- 🎮 **Interface jeu vidéo** avec HUD, métriques, contrôles
- 🔊 **Visualiseur audio** animé pendant les dialogues

## 🚀 Quick Start

### Prérequis
- Node.js 20+
- npm ou yarn

### Installation

```bash
# Cloner le repo
git clone https://github.com/ton-username/nomos42-pnl-3d.git
cd nomos42-pnl-3d

# Installer les dépendances
npm install

# Lancer en dev
npm run dev

# Build pour production
npm run build
```

### Déploiement Hugging Face Space

1. Créer un Space sur [Hugging Face](https://huggingface.co/spaces)
2. Choisir **Static** comme type
3. Uploader le contenu du dossier `dist/` après build

Ou utiliser Git:
```bash
# Build
npm run build

# Push vers HF Space
cd dist
git init
git add .
git commit -m "Deploy NOMOS42"
git push https://huggingface.co/spaces/TON_USERNAME/nomos42-pnl main
```

## 📁 Structure du projet

```
nomos42-pnl-3d/
├── public/
│   ├── ademo-character.jpg    # Personnage ADEMO
│   ├── nos-character.jpg      # Personnage N.O.S (Deux Frères)
│   ├── monk-character.jpg     # Personnage MONK (singe DBZ)
│   └── environment-bg.jpg     # Fond sicilien
├── src/
│   ├── App.tsx               # Composant principal 3D
│   ├── App.css               # Styles cyberpunk/PNL
│   ├── main.tsx              # Entry point
│   ├── hooks/
│   │   └── useLiveData.ts    # Hook pour données live (optionnel)
│   └── types/
│       └── index.ts          # Types TypeScript
├── package.json
├── vite.config.ts
├── tsconfig.json
└── README.md
```

## 🔌 Intégration données live

Pour connecter les vraies conversations de tes agents IA :

### Option 1 : WebSocket
Modifier `src/hooks/useLiveData.ts` :

```typescript
import { useEffect, useState } from 'react'

export function useLiveData() {
  const [messages, setMessages] = useState([])
  
  useEffect(() => {
    const ws = new WebSocket('wss://ton-websocket-url')
    ws.onmessage = (event) => {
      const data = JSON.parse(event.data)
      setMessages(prev => [...prev, data])
    }
    return () => ws.close()
  }, [])
  
  return messages
}
```

### Option 2 : API Polling
```typescript
export function useLiveData() {
  const [messages, setMessages] = useState([])
  
  useEffect(() => {
    const interval = setInterval(async () => {
      const res = await fetch('https://ton-api-url/messages')
      const data = await res.json()
      setMessages(data)
    }, 2000)
    return () => clearInterval(interval)
  }, [])
  
  return messages
}
```

### Option 3 : Fichier JSON local
Créer `public/live-data.json` et le fetch :

```typescript
const response = await fetch('/live-data.json')
const messages = await response.json()
```

## 🎨 Personnalisation

### Changer les couleurs
Modifier `src/App.css` :
```css
:root {
  --pnl-cyan: #00d4ff;      /* N.O.S */
  --pnl-orange: #ff6b35;    /* ADEMO */
  --pnl-green: #00ff88;     /* MONK */
  --pnl-pink: #ff00ff;      /* Accent */
}
```

### Ajouter un agent
Dans `src/App.tsx` :
```typescript
const agents: Agent[] = [
  {
    id: 'nouvel-agent',
    name: 'NOUVEAU',
    role: 'Role description',
    image: '/nouveau-character.jpg',
    color: '#ff0000',
    position: [6, 0, 0]
  }
]
```

## 📸 Screenshots

| Personnages 3D | Dialogue Live | Métriques |
|----------------|---------------|-----------|
| ![chars](./docs/chars.png) | ![dialogue](./docs/dialogue.png) | ![metrics](./docs/metrics.png) |

## 🎵 Univers PNL

- **Deux Frères** (2019) - Album inspirant l'esthétique sicilienne
- **Dans la légende** (2016) - L'identité visuelle QLF
- **Le Monde Chico** (2015) - Les débuts

## 🛠️ Tech Stack

- **React 19** - UI Framework
- **Three.js** - Moteur 3D
- **React Three Fiber** - Renderer React pour Three.js
- **Drei** - Helpers R3F
- **Post Processing** - Effets visuels
- **Vite** - Build tool
- **TypeScript** - Type safety

## 📝 License

MIT - Libre d'utilisation pour tes projets NOMOS42

---

**QLF** 🚀
