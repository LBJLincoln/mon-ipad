# RAG Engineering Handbook

Comprehensive technical documentation from building a production multi-pipeline RAG system evaluated on 61,000+ questions.

## Contents

| Document | Pages | Description |
|----------|-------|-------------|
| `DEBUG-PLAYBOOK.md` | ~80 | 79 production fixes with symptoms, root causes, and solutions |
| `INFRASTRUCTURE.md` | ~40 | Full stack documentation (databases, LLMs, embeddings, deployment) |
| `PROJECT-ROADMAP.md` | ~30 | Development phases, research insights, optimization strategies |

## What You'll Learn

### From DEBUG-PLAYBOOK.md
- How to diagnose RAG retrieval failures systematically
- Common n8n workflow pitfalls and fixes
- Database-specific patterns (Pinecone, Neo4j, Supabase)
- LLM prompt engineering for RAG synthesis
- Performance tuning for production workloads

### From INFRASTRUCTURE.md
- Multi-database architecture (vector + graph + relational)
- Self-hosted embedding deployment patterns
- n8n workflow orchestration at scale
- Free-tier LLM routing strategies
- Monitoring and observability setup

### From PROJECT-ROADMAP.md
- Phased evaluation methodology (200 -> 10K -> 61K questions)
- SOTA research integration (Cohere Rerank, CRAG, late_chunking)
- Accuracy improvement strategies per pipeline type
- Bottleneck analysis and resolution patterns

## Who This Is For

- **RAG engineers** building production retrieval systems
- **AI engineers** working with n8n, LangChain, or similar orchestrators
- **Technical leaders** evaluating RAG architecture decisions
- **AI coding agents** needing deep RAG context

---
(c) Nomos AI. All rights reserved.
