# Agent Routing Patterns — 12 Strategies for Multi-Pipeline RAG

> From the Agentic RAG Blueprint | Nomos AI | Based on 88+ production sessions

---

## Pattern 1: Intent-Based Classification

Route queries based on detected intent using LLM classification.

```
Query → LLM Classifier → {factual, analytical, quantitative, exploratory}
                        → Pipeline Selection
```

**Implementation:**
- System prompt with intent taxonomy
- Few-shot examples per intent category
- Confidence threshold: route to orchestrator below 0.7

**Accuracy:** 91% correct routing on 10K test queries

---

## Pattern 2: Keyword Signal Routing

Fast, zero-LLM routing based on keyword patterns.

| Signal | Pipeline | Examples |
|--------|----------|----------|
| Numbers, %, $, metrics | Quantitative | "revenue growth", "Q3 2025" |
| Relationships, connected, between | Graph | "related companies", "supply chain" |
| How, what, explain, describe | Standard | "how does X work" |
| Compare, versus, tradeoffs | Orchestrator | "compare A vs B" |

**Latency:** <5ms vs 500ms+ for LLM classification

---

## Pattern 3: Hybrid Cascade

1. Keyword routing (fast path) — handles 60% of queries
2. LLM classification (remaining) — handles 35%
3. Orchestrator fallback — handles 5% ambiguous

**Best of both worlds:** Speed + accuracy

---

## Pattern 4: Query Complexity Scoring

Score queries on a 1-5 complexity scale:
- 1-2: Standard RAG (single retrieval)
- 3: Graph RAG (entity relationships needed)
- 4: Quantitative RAG (numerical precision required)
- 5: Orchestrator (multi-pipeline fusion)

Scoring factors: entity count, temporal references, numerical content, relationship depth

---

## Pattern 5: Embedding-Space Routing

Pre-compute cluster centroids for each pipeline's ideal queries.
Route new queries to the nearest cluster.

```python
centroids = {
    "standard": embed(standard_exemplars).mean(axis=0),
    "graph": embed(graph_exemplars).mean(axis=0),
    "quantitative": embed(quant_exemplars).mean(axis=0),
}
pipeline = min(centroids, key=lambda k: cosine_distance(query_emb, centroids[k]))
```

**Requires:** 50+ exemplar queries per pipeline for stable centroids

---

## Pattern 6: Multi-Armed Bandit Routing

Explore-exploit: try different pipelines, learn which works best per query type.

- Thompson Sampling with Beta distributions per (query_type, pipeline) pair
- Update rewards based on answer quality scores
- Converges to optimal routing within ~200 queries

---

## Pattern 7: Confidence-Based Cascading

1. Try fastest pipeline first (Standard)
2. If confidence < threshold → try next pipeline
3. If all below threshold → orchestrate all pipelines

**Thresholds:** Standard > 0.8, Graph > 0.75, Quant > 0.85

---

## Pattern 8: Query Decomposition Routing

Complex queries → decompose into sub-queries → route each independently.

```
"Compare Q3 revenue with industry benchmarks and explain the supply chain impact"
  → Sub-1: "Q3 revenue figures" → Quantitative
  → Sub-2: "industry benchmarks" → Standard
  → Sub-3: "supply chain relationships" → Graph
  → Merge results
```

---

## Pattern 9: Temporal Routing

Route based on temporal characteristics:
- Real-time/recent: Standard (freshest index)
- Historical trends: Quantitative (time-series capable)
- Relationship evolution: Graph (temporal edges)

---

## Pattern 10: Domain-Specific Routing

Pre-classify by domain, then route:

| Domain | Primary Pipeline | Fallback |
|--------|-----------------|----------|
| Finance | Quantitative | Standard |
| Legal | Standard | Graph |
| Manufacturing | Graph | Standard |
| Construction | Standard | Quantitative |

---

## Pattern 11: User Feedback Loop Routing

Track user satisfaction per pipeline response:
- Thumbs up/down → update routing weights
- Explicit corrections → retrain classifier
- Session patterns → personalize routing

---

## Pattern 12: Cost-Aware Routing

Route based on cost budget:
- Free tier remaining → expensive pipeline OK
- Near limit → keyword routing only
- Rate limited → queue + fallback

```python
if rate_limiter.remaining("groq") > 10:
    route_to_llm_classifier()
elif rate_limiter.remaining("openrouter") > 0:
    route_to_lite_classifier()
else:
    route_by_keywords()
```

---

## Routing Decision Matrix

| Scenario | Best Pattern | Why |
|----------|-------------|-----|
| Low latency required | Keyword Signal (#2) | No LLM call |
| High accuracy required | Hybrid Cascade (#3) | Best of both |
| Limited compute | Cost-Aware (#12) | Budget control |
| Cold start | Intent Classification (#1) | No historical data needed |
| Mature system | Multi-Armed Bandit (#6) | Self-optimizing |
| Complex queries | Query Decomposition (#8) | Handles multi-part |

---

*Part of the Agentic RAG Blueprint ($147) — nomos.ai*
