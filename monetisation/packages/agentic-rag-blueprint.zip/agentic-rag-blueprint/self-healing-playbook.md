# Self-Healing RAG Playbook — Failure Recovery Patterns

> From the Agentic RAG Blueprint | Nomos AI | 88+ production sessions

---

## The 7 Self-Healing Patterns

### Pattern 1: Intelligent Retry with Exponential Backoff

```python
async def resilient_call(func, max_retries=3):
    for attempt in range(max_retries):
        try:
            return await func()
        except RateLimitError:
            wait = min(2 ** attempt * 1.5, 30)
            await asyncio.sleep(wait + random.uniform(0, 1))
        except TimeoutError:
            if attempt == max_retries - 1:
                return fallback_response()
    return fallback_response()
```

**Key insight:** Add jitter to prevent thundering herd. Cap backoff at 30s.

---

### Pattern 2: LLM Provider Fallback Chain

When primary LLM fails, cascade through alternatives:

```
Groq (llama-3.3-70b) → OpenRouter (gemma-3-27b) → Local (tiny model)
```

**Implementation in n8n:**
- HTTP node with error output → Switch node → Secondary provider
- Track which provider succeeded for monitoring

**Production stats:** 99.7% availability with 3-provider chain vs 94% with single provider

---

### Pattern 3: Circuit Breaker

Prevent cascading failures by temporarily disabling broken services:

```python
class CircuitBreaker:
    CLOSED = "closed"      # Normal operation
    OPEN = "open"          # Service broken, skip
    HALF_OPEN = "half"     # Testing recovery

    def __init__(self, failure_threshold=5, recovery_timeout=60):
        self.state = self.CLOSED
        self.failures = 0
        self.last_failure = None

    def call(self, func):
        if self.state == self.OPEN:
            if time.time() - self.last_failure > self.recovery_timeout:
                self.state = self.HALF_OPEN
            else:
                raise CircuitOpenError()

        try:
            result = func()
            if self.state == self.HALF_OPEN:
                self.state = self.CLOSED
                self.failures = 0
            return result
        except Exception:
            self.failures += 1
            self.last_failure = time.time()
            if self.failures >= self.failure_threshold:
                self.state = self.OPEN
            raise
```

---

### Pattern 4: Empty Retrieval Recovery

When vector search returns 0 results or low-relevance results:

1. **Relax filters:** Remove metadata filters, widen date range
2. **Query reformulation:** Use LLM to rephrase query
3. **HyDE generation:** Generate hypothetical document, embed that instead
4. **BM25 fallback:** Switch from semantic to keyword search
5. **Cross-index search:** Try different Pinecone index/namespace

**Decision tree:**
```
0 results → Relax filters → Still 0? → HyDE → Still 0? → BM25
Low relevance (score < 0.3) → Query reformulation → Retry
```

---

### Pattern 5: Graceful Degradation

When full pipeline fails, degrade quality rather than returning nothing:

| Level | What Works | Response Quality |
|-------|-----------|-----------------|
| Full | All components | Best (87.5%) |
| Degraded | No reranker | Good (82%) |
| Minimal | BM25 only, no LLM rewrite | Acceptable (70%) |
| Cache | Previous similar answers | Variable |
| Honest | "I don't have enough information" | Transparent |

---

### Pattern 6: Self-Correcting Retrieval

Agent evaluates its own retrieval quality and retries:

```python
async def self_correcting_retrieve(query, max_rounds=3):
    for round in range(max_rounds):
        docs = await retrieve(query)

        # Self-evaluation
        quality = await llm_judge(query, docs)

        if quality.score > 0.7:
            return docs

        # Self-correction
        query = await reformulate(query, quality.feedback)

    return docs  # Best effort
```

---

### Pattern 7: Eval-Triggered Rollback

Automated rollback when accuracy drops:

```bash
# Run quick eval after each deployment
accuracy=$(python3 eval/quick-test.py --questions 10 --pipeline standard | grep "Accuracy" | awk '{print $2}')

if (( $(echo "$accuracy < 80.0" | bc -l) )); then
    echo "REGRESSION DETECTED: $accuracy% < 80% threshold"
    git revert HEAD --no-edit
    git push
    # Alert
fi
```

**Thresholds:**
- Standard: < 80% → rollback
- Quant: < 90% → rollback
- Graph: < 35% → rollback (lower bar, known issues)

---

## Monitoring Checklist

- [ ] LLM provider response times (p50, p95, p99)
- [ ] Retrieval empty rate (target: < 5%)
- [ ] Circuit breaker state per service
- [ ] Fallback activation frequency
- [ ] Accuracy trend (7-day rolling average)
- [ ] Cost per query (track free tier usage)

---

*Part of the Agentic RAG Blueprint ($147) — nomos.ai*
