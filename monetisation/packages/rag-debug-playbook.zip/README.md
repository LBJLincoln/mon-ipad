# RAG Debug Playbook -- 79 Production Fixes

Open in any Markdown editor or drop into your AI coding agent's context.

## What's Inside

A battle-tested collection of 79 production fixes for RAG (Retrieval-Augmented Generation) systems, organized by category:

- **Retrieval failures** -- empty results, wrong index, embedding mismatches
- **LLM integration** -- prompt engineering, token limits, model routing
- **Database issues** -- Pinecone, Neo4j, Supabase connection patterns
- **Pipeline orchestration** -- n8n workflow debugging, webhook routing
- **Performance** -- batch sizing, concurrency, timeout tuning
- **Monitoring** -- error detection, regression testing, golden eval sets

## How to Use

1. **As a reference** -- Search by error message or symptom
2. **As AI context** -- Drop into Claude Code, Cursor, or Copilot as project context
3. **As a checklist** -- Walk through categories when debugging a new RAG system

## Format

Each fix follows a consistent structure:
- **FIX-XX**: Title
- **Symptom**: What you observe
- **Root cause**: Why it happens
- **Solution**: Step-by-step fix
- **Prevention**: How to avoid recurrence

---
(c) Nomos AI. All rights reserved.
