# AI Agent Context Kit -- RAG Engineering Edition

Drop these files into your AI coding agent's context window for instant RAG expertise.

## Contents

| File | Purpose | Best For |
|------|---------|----------|
| `RAG-DEBUG-CONTEXT.md` | Debugging context for AI agents | Claude Code, Cursor, Copilot |
| `RAG-ARCHITECTURE-REFERENCE.md` | System architecture patterns | Design decisions, code review |
| `PROMPT-TEMPLATES.md` | Production prompt templates | LLM node configuration |

## How to Install

### Claude Code
```bash
cp *.md /your-project/.claude/
# Or reference in CLAUDE.md
```

### Cursor
Drop files into `.cursor/` or reference in `.cursorrules`.

### GitHub Copilot
Add to `.github/copilot-instructions.md` or workspace context.

### Generic
Add to your project root or AI context directory.

## What You Get

- **40+ prompt templates** for RAG pipeline nodes (intent, retrieval, synthesis, grading)
- **Architecture patterns** for multi-pipeline RAG (Standard, Graph, Quantitative)
- **Debug workflows** that AI agents can follow step-by-step
- **Production-tested** on 61,000+ questions across 18 SOTA benchmarks

---
(c) Nomos AI. All rights reserved.
