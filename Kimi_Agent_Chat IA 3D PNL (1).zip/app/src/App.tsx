import { useState, useEffect, useRef, useMemo } from 'react'
import { Canvas, useFrame, useThree } from '@react-three/fiber'
import { 
  Environment, 
  PerspectiveCamera, 
  useTexture, 
  Stars,
  Text,
  MeshReflectorMaterial
} from '@react-three/drei'
import { EffectComposer, Bloom, ChromaticAberration, Vignette, SSAO, DepthOfField } from '@react-three/postprocessing'
import * as THREE from 'three'
import './App.css'

// ============================================
// TYPES
// ============================================

type MessageType = 'status' | 'analysis' | 'action' | 'discovery' | 'error'

interface Message {
  id: string
  agent: 'N.O.S' | 'ADEMO' | 'MONK'
  content: string
  timestamp: string
  type: MessageType
}

interface Agent {
  id: string
  name: 'N.O.S' | 'ADEMO' | 'MONK'
  role: string
  image: string
  color: string
  position: [number, number, number]
}

interface Metrics {
  brier: string
  accuracy: string
  roi: string
  features: string
  generation: string
  population: string
}

// ============================================
// DONNÉES
// ============================================

const STATIC_CONVERSATION: Message[] = [
  { id: '1', agent: 'N.O.S', content: 'Yo ADEMO, le système est stable ?', timestamp: new Date().toISOString(), type: 'status' },
  { id: '2', agent: 'ADEMO', content: 'Brier à 1.0000, on a un problème de pipeline', timestamp: new Date().toISOString(), type: 'analysis' },
  { id: '3', agent: 'MONK', content: 'Diagnosis: S10 stuck in STARTING state', timestamp: new Date().toISOString(), type: 'analysis' },
  { id: '4', agent: 'MONK', content: 'AUTO-FIX applied: population reset ⚡', timestamp: new Date().toISOString(), type: 'action' },
  { id: '5', agent: 'ADEMO', content: 'Discovery: rest_schedule features +4', timestamp: new Date().toISOString(), type: 'discovery' },
  { id: '6', agent: 'N.O.S', content: 'Tactical: model outputting opposite labels', timestamp: new Date().toISOString(), type: 'analysis' },
]

const AGENTS: Agent[] = [
  { id: 'nos', name: 'N.O.S', role: 'Strategic Commander', image: '/nos-character.jpg', color: '#c9a227', position: [-4, 0, 0] },
  { id: 'ademo', name: 'ADEMO', role: 'Research & Execution', image: '/ademo-character.jpg', color: '#ff6b35', position: [0, 0, 0] },
  { id: 'monk', name: 'MONK', role: 'Evolution Engine', image: '/monk-character.jpg', color: '#00ff88', position: [4, 0, 0] }
]

// ============================================
// ENVIRONNEMENT 3D JEU VIDÉO
// ============================================

function CityEnvironment() {
  return (
    <group>
      {/* Sol réfléchissant style GTA VI */}
      <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, -0.1, 0]}>
        <planeGeometry args={[100, 100]} />
        <MeshReflectorMaterial
          resolution={1024}
          mirror={0.75}
          mixBlur={0.8}
          mixStrength={0.8}
          color="#1a1a2e"
          metalness={0.9}
          roughness={0.1}
        />
      </mesh>
      
      {/* Bâtiments en arrière-plan */}
      {[-30, -15, 15, 30].map((x, i) => (
        <Building key={i} position={[x, 5, -20]} height={10 + Math.random() * 15} />
      ))}
      
      {/* Néons et enseignes */}
      <NeonSign position={[-10, 3, -10]} text="QLF" color="#ff6b35" />
      <NeonSign position={[10, 3, -10]} text="NOMOS42" color="#00d4ff" />
      <NeonSign position={[0, 5, -15]} text="DEUX FRÈRES" color="#c9a227" />
      
      {/* Lampadaires */}
      <StreetLight position={[-8, 0, -5]} />
      <StreetLight position={[8, 0, -5]} />
      <StreetLight position={[-8, 0, 5]} />
      <StreetLight position={[8, 0, 5]} />
      
      {/* Particules atmosphériques */}
      <AtmosphericParticles />
      
      {/* Fumée/vapeur au sol */}
      <GroundFog />
    </group>
  )
}

function Building({ position, height }: { position: [number, number, number], height: number }) {
  return (
    <group position={position}>
      <mesh position={[0, height / 2, 0]}>
        <boxGeometry args={[8, height, 8]} />
        <meshStandardMaterial color="#0a0a15" roughness={0.8} metalness={0.2} />
      </mesh>
      {/* Fenêtres lumineuses */}
      {Array.from({ length: Math.floor(height / 2) }).map((_, i) => (
        <mesh key={i} position={[0, i * 2 + 1, 4.1]}>
          <planeGeometry args={[6, 1.5]} />
          <meshBasicMaterial color={Math.random() > 0.5 ? '#ffdd88' : '#1a1a2e'} />
        </mesh>
      ))}
    </group>
  )
}

function NeonSign({ position, text, color }: { position: [number, number, number], text: string, color: string }) {
  const materialRef = useRef<THREE.MeshStandardMaterial>(null)
  
  useFrame((state) => {
    if (materialRef.current) {
      const intensity = 1 + Math.sin(state.clock.elapsedTime * 3) * 0.3
      materialRef.current.emissiveIntensity = intensity
    }
  })
  
  return (
    <group position={position}>
      <Text
        fontSize={1.5}
        color={color}
        anchorX="center"
        anchorY="middle"
      >
        {text}
        <meshStandardMaterial
          ref={materialRef}
          color={color}
          emissive={color}
          emissiveIntensity={1}
          toneMapped={false}
        />
      </Text>
      {/* Glow backing */}
      <mesh position={[0, 0, -0.1]}>
        <planeGeometry args={[text.length * 0.8, 2]} />
        <meshBasicMaterial color={color} transparent opacity={0.2} />
      </mesh>
    </group>
  )
}

function StreetLight({ position }: { position: [number, number, number] }) {
  return (
    <group position={position}>
      {/* Poteau */}
      <mesh position={[0, 3, 0]}>
        <cylinderGeometry args={[0.1, 0.15, 6]} />
        <meshStandardMaterial color="#333" metalness={0.8} />
      </mesh>
      {/* Lumière */}
      <mesh position={[0, 6, 0]}>
        <sphereGeometry args={[0.3]} />
        <meshBasicMaterial color="#ffdd88" />
      </mesh>
      <pointLight position={[0, 6, 0]} intensity={2} distance={15} color="#ffdd88" />
      {/* Cone de lumière */}
      <mesh position={[0, 5.5, 0]} rotation={[Math.PI, 0, 0]}>
        <coneGeometry args={[2, 4, 32, 1, true]} />
        <meshBasicMaterial color="#ffdd88" transparent opacity={0.1} side={THREE.DoubleSide} />
      </mesh>
    </group>
  )
}

function AtmosphericParticles() {
  const pointsRef = useRef<THREE.Points>(null)
  const particleCount = 1000
  
  const positions = useMemo(() => {
    const pos = new Float32Array(particleCount * 3)
    for (let i = 0; i < particleCount; i++) {
      pos[i * 3] = (Math.random() - 0.5) * 60
      pos[i * 3 + 1] = Math.random() * 20
      pos[i * 3 + 2] = (Math.random() - 0.5) * 40
    }
    return pos
  }, [])
  
  useFrame((state) => {
    if (pointsRef.current) {
      pointsRef.current.rotation.y = state.clock.elapsedTime * 0.02
      const posArray = pointsRef.current.geometry.attributes.position.array as Float32Array
      for (let i = 0; i < particleCount; i++) {
        posArray[i * 3 + 1] += Math.sin(state.clock.elapsedTime + i) * 0.01
      }
      pointsRef.current.geometry.attributes.position.needsUpdate = true
    }
  })
  
  return (
    <points ref={pointsRef}>
      <bufferGeometry>
        <bufferAttribute attach="attributes-position" args={[positions, 3]} />
      </bufferGeometry>
      <pointsMaterial size={0.05} color="#c9a227" transparent opacity={0.6} sizeAttenuation />
    </points>
  )
}

function GroundFog() {
  const meshRef = useRef<THREE.Mesh>(null)
  const materialRef = useRef<THREE.MeshBasicMaterial>(null)
  
  useFrame((state) => {
    if (materialRef.current) {
      materialRef.current.opacity = 0.3 + Math.sin(state.clock.elapsedTime * 0.5) * 0.1
    }
  })
  
  return (
    <mesh ref={meshRef} rotation={[-Math.PI / 2, 0, 0]} position={[0, 0.1, 0]}>
      <planeGeometry args={[60, 60]} />
      <meshBasicMaterial ref={materialRef} color="#4a4a6a" transparent opacity={0.3} />
    </mesh>
  )
}

// ============================================
// PERSONNAGE 3D ANIMÉ AVEC MARCHE
// ============================================

function AnimatedCharacter({ agent, isActive, isSpeaking }: { 
  agent: Agent
  isActive: boolean
  isSpeaking: boolean
}) {
  const groupRef = useRef<THREE.Group>(null)
  const texture = useTexture(agent.image)
  const [currentPos] = useState(agent.position)
  const walkCycle = useRef(0)
  
  // Animation de marche/idle
  useFrame((state, delta) => {
    if (!groupRef.current) return
    
    // Position de base
    groupRef.current.position.set(currentPos[0], currentPos[1], currentPos[2])
    
    // Animation idle - respiration
    walkCycle.current += delta * 2
    groupRef.current.position.y = Math.sin(walkCycle.current) * 0.05
    
    // Glow quand actif
    if (isActive) {
      const scale = 1 + Math.sin(state.clock.elapsedTime * 4) * 0.02
      groupRef.current.scale.setScalar(scale)
    } else {
      groupRef.current.scale.setScalar(1)
    }
  })
  
  return (
    <group ref={groupRef}>
      {/* Ombre au sol */}
      <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, 0.01, 0]}>
        <circleGeometry args={[1, 32]} />
        <meshBasicMaterial color="#000" transparent opacity={0.5} />
      </mesh>
      
      {/* Personnage (billboard qui fait face à la caméra) */}
      <BillboardSprite texture={texture} agent={agent} isSpeaking={isSpeaking} />
      
      {/* Indicateur de parole */}
      {isSpeaking && <SpeechIndicator color={agent.color} />}
      
      {/* Halo quand actif */}
      {isActive && (
        <mesh position={[0, -0.5, 0]} rotation={[-Math.PI / 2, 0, 0]}>
          <ringGeometry args={[1.2, 1.5, 32]} />
          <meshBasicMaterial color={agent.color} transparent opacity={0.5} side={THREE.DoubleSide} />
        </mesh>
      )}
    </group>
  )
}

function BillboardSprite({ texture, agent, isSpeaking }: { texture: THREE.Texture, agent: Agent, isSpeaking: boolean }) {
  const meshRef = useRef<THREE.Mesh>(null)
  const { camera } = useThree()
  
  useFrame(() => {
    if (meshRef.current) {
      // Fait face à la caméra (billboard)
      meshRef.current.lookAt(camera.position)
    }
  })
  
  return (
    <mesh ref={meshRef}>
      <planeGeometry args={[2.5, 4]} />
      <meshBasicMaterial map={texture} transparent side={THREE.DoubleSide} />
      
      {/* Bordure glow */}
      <mesh position={[0, 0, -0.01]}>
        <planeGeometry args={[2.6, 4.1]} />
        <meshBasicMaterial color={agent.color} transparent opacity={isSpeaking ? 0.5 : 0.2} />
      </mesh>
    </mesh>
  )
}

function SpeechIndicator({ color }: { color: string }) {
  const ref = useRef<THREE.Group>(null)
  
  useFrame((state) => {
    if (ref.current) {
      ref.current.position.y = 2.5 + Math.sin(state.clock.elapsedTime * 4) * 0.2
    }
  })
  
  return (
    <group ref={ref} position={[0, 2.5, 0]}>
      {/* Points de suspension animés */}
      {[0, 0.3, 0.6].map((x, i) => (
        <mesh key={i} position={[x - 0.3, 0, 0]}>
          <sphereGeometry args={[0.08]} />
          <meshBasicMaterial color={color} />
        </mesh>
      ))}
    </group>
  )
}

// ============================================
// CAMÉRA DYNAMIQUE STYLE GTA
// ============================================

function DynamicCamera({ targetAgent }: { targetAgent: string | null }) {
  const cameraRef = useRef<THREE.PerspectiveCamera>(null)
  const targetRef = useRef(new THREE.Vector3(0, 2, 8))
  
  useFrame((state) => {
    if (!cameraRef.current) return
    
    // Position cible basée sur l'agent actif
    let targetPos = new THREE.Vector3(0, 2, 8)
    
    if (targetAgent) {
      const agent = AGENTS.find(a => a.id === targetAgent)
      if (agent) {
        targetPos = new THREE.Vector3(agent.position[0] + 3, 3, 6)
      }
    }
    
    // Mouvement fluide de la caméra
    targetRef.current.lerp(targetPos, 0.03)
    cameraRef.current.position.copy(targetRef.current)
    cameraRef.current.lookAt(0, 1.5, 0)
    
    // Léger mouvement de caméra style handheld
    const time = state.clock.elapsedTime
    cameraRef.current.position.x += Math.sin(time * 0.5) * 0.02
    cameraRef.current.position.y += Math.cos(time * 0.3) * 0.02
  })
  
  return (
    <PerspectiveCamera
      ref={cameraRef}
      makeDefault
      position={[0, 3, 10]}
      fov={60}
      near={0.1}
      far={1000}
    />
  )
}

// ============================================
// SCÈNE PRINCIPALE
// ============================================

function GameScene({ activeAgent, speakingAgent }: { activeAgent: string | null, speakingAgent: string | null }) {
  return (
    <>
      <DynamicCamera targetAgent={activeAgent} />
      
      {/* Lumières */}
      <ambientLight intensity={0.2} />
      <Environment preset="night" />
      
      {/* Lumière directionnelle (lune) */}
      <directionalLight
        position={[-10, 20, -10]}
        intensity={0.5}
        color="#4466aa"
        castShadow
        shadow-mapSize={[2048, 2048]}
      />
      
      {/* Lumières colorées style néon */}
      <pointLight position={[-10, 3, -10]} intensity={2} color="#ff6b35" distance={20} />
      <pointLight position={[10, 3, -10]} intensity={2} color="#00d4ff" distance={20} />
      <pointLight position={[0, 5, -15]} intensity={1.5} color="#c9a227" distance={25} />
      
      {/* Environnement ville */}
      <CityEnvironment />
      
      {/* Étoiles */}
      <Stars radius={100} depth={50} count={3000} factor={4} saturation={0.5} fade speed={1} />
      
      {/* Personnages animés */}
      {AGENTS.map((agent) => (
        <AnimatedCharacter
          key={agent.id}
          agent={agent}
          isActive={activeAgent === agent.id}
          isSpeaking={speakingAgent === agent.id}
        />
      ))}
      
      {/* Post-processing next-gen */}
      <EffectComposer>
        <SSAO
          samples={16}
          radius={0.5}
          intensity={20}
        />
        <Bloom
          intensity={1.5}
          luminanceThreshold={0.3}
          luminanceSmoothing={0.8}
          mipmapBlur
        />
        <ChromaticAberration offset={[0.002, 0.002]} />
        <Vignette eskil={false} offset={0.2} darkness={0.7} />
        <DepthOfField
          focusDistance={0.02}
          focalLength={0.05}
          bokehScale={3}
        />
      </EffectComposer>
      
      {/* Fog atmosphérique */}
      <fog attach="fog" args={['#0a0a15', 10, 50]} />
    </>
  )
}

// ============================================
// UI HUD STYLE JEU VIDÉO
// ============================================

function HUD({ message, isPlaying, onPlayPause, currentIndex, totalMessages, metrics }: {
  message: Message | null
  isPlaying: boolean
  onPlayPause: () => void
  currentIndex: number
  totalMessages: number
  metrics: Metrics
}) {
  const agent = message ? AGENTS.find(a => a.name === message.agent) : null
  
  return (
    <div className="game-hud">
      {/* Minimap en haut à droite */}
      <div className="minimap">
        <div className="minimap-title">NOMOS42</div>
        <div className="minimap-content">
          {AGENTS.map(a => (
            <div 
              key={a.id} 
              className={`minimap-dot ${a.id === agent?.id ? 'active' : ''}`}
              style={{ 
                left: `${50 + (a.position[0] / 10) * 40}%`,
                top: `${50}%`,
                backgroundColor: a.color
              }}
            />
          ))}
        </div>
      </div>
      
      {/* Stats en haut à gauche */}
      <div className="stats-panel">
        <div className="stat-row">
          <span className="stat-label">BRIER</span>
          <span className="stat-value" style={{ color: '#00d4ff' }}>{metrics.brier}</span>
        </div>
        <div className="stat-row">
          <span className="stat-label">ACCURACY</span>
          <span className="stat-value" style={{ color: '#ff6b35' }}>{metrics.accuracy}</span>
        </div>
        <div className="stat-row">
          <span className="stat-label">FEATURES</span>
          <span className="stat-value" style={{ color: '#00ff88' }}>{metrics.features}</span>
        </div>
      </div>
      
      {/* Dialogue en bas style GTA */}
      {message && (
        <div className="dialogue-box-game" style={{ borderColor: agent?.color }}>
          <div className="dialogue-speaker" style={{ color: agent?.color }}>
            {agent?.name}
            <span className="speaker-role">{agent?.role}</span>
          </div>
          <div className="dialogue-text">{message.content}</div>
          <div className="dialogue-type">{message.type.toUpperCase()}</div>
        </div>
      )}
      
      {/* Contrôles en bas à droite */}
      <div className="game-controls">
        <button className="game-btn" onClick={onPlayPause}>
          {isPlaying ? '⏸ PAUSE' : '▶ PLAY'}
        </button>
        <div className="progress-bar-game">
          {Array.from({ length: totalMessages }).map((_, i) => (
            <div 
              key={i} 
              className={`progress-segment ${i <= currentIndex ? 'filled' : ''}`}
            />
          ))}
        </div>
      </div>
      
      {/* Logo QLF */}
      <div className="qlf-logo">QLF</div>
    </div>
  )
}

// ============================================
// APP PRINCIPAL
// ============================================

function App() {
  const [currentIndex, setCurrentIndex] = useState(0)
  const [isPlaying, setIsPlaying] = useState(true)
  const [activeAgent, setActiveAgent] = useState<string | null>(null)
  const [speakingAgent, setSpeakingAgent] = useState<string | null>(null)
  
  const metrics: Metrics = {
    brier: '1.0000',
    accuracy: '0.0%',
    roi: '—',
    features: '9',
    generation: '0',
    population: '0'
  }
  
  const currentMessage = STATIC_CONVERSATION[currentIndex]
  
  useEffect(() => {
    if (!isPlaying) return
    
    const interval = setInterval(() => {
      setCurrentIndex(prev => {
        const next = (prev + 1) % STATIC_CONVERSATION.length
        const message = STATIC_CONVERSATION[next]
        const agent = AGENTS.find(a => a.name === message.agent)
        
        setActiveAgent(agent?.id || null)
        setSpeakingAgent(agent?.id || null)
        
        setTimeout(() => setSpeakingAgent(null), 2000)
        
        return next
      })
    }, 5000)
    
    return () => clearInterval(interval)
  }, [isPlaying])
  
  return (
    <div className="game-container">
      <Canvas shadows dpr={[1, 2]} gl={{ antialias: true, alpha: false }}>
        <GameScene activeAgent={activeAgent} speakingAgent={speakingAgent} />
      </Canvas>
      
      <HUD
        message={currentMessage}
        isPlaying={isPlaying}
        onPlayPause={() => setIsPlaying(!isPlaying)}
        currentIndex={currentIndex}
        totalMessages={STATIC_CONVERSATION.length}
        metrics={metrics}
      />
    </div>
  )
}

export default App
