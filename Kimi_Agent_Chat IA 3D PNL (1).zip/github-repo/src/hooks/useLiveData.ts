import { useState, useEffect, useCallback } from 'react'
import type { Message, LiveDataPayload } from '../types'

// ============================================
// HOOK POUR DONNÉES LIVE - NOMOS42
// ============================================
// 
// Ce hook permet de connecter les vraies conversations
// de tes agents IA à l'interface 3D
//
// OPTIONS:
// 1. WebSocket (recommandé pour temps réel)
// 2. API Polling (simple)
// 3. Fichier JSON local (développement)
// 4. EventSource (Server-Sent Events)
//
// ============================================

interface UseLiveDataOptions {
  /** URL de ton endpoint WebSocket/API */
  url?: string
  /** Type de connexion */
  mode: 'websocket' | 'polling' | 'json' | 'eventsource'
  /** Intervalle pour polling (ms) */
  pollingInterval?: number
  /** Callback quand nouveau message reçu */
  onMessage?: (message: Message) => void
}

export function useLiveData(options: UseLiveDataOptions) {
  const [messages, setMessages] = useState<Message[]>([])
  const [isConnected, setIsConnected] = useState(false)
  const [error, setError] = useState<string | null>(null)

  // ============================================
  // OPTION 1: WEBSOCKET (Recommandé)
  // ============================================
  const connectWebSocket = useCallback(() => {
    if (!options.url) {
      setError('URL WebSocket requise')
      return
    }

    const ws = new WebSocket(options.url)

    ws.onopen = () => {
      setIsConnected(true)
      setError(null)
      console.log('[NOMOS42] WebSocket connecté')
    }

    ws.onmessage = (event) => {
      try {
        const data: LiveDataPayload = JSON.parse(event.data)
        const message: Message = {
          id: Date.now().toString(),
          agent: data.agent as Message['agent'],
          content: data.message,
          timestamp: data.timestamp,
          type: data.type
        }
        setMessages(prev => [...prev, message])
        options.onMessage?.(message)
      } catch (err) {
        console.error('[NOMOS42] Erreur parsing message:', err)
      }
    }

    ws.onerror = (err) => {
      setError('Erreur WebSocket')
      setIsConnected(false)
      console.error('[NOMOS42] WebSocket error:', err)
    }

    ws.onclose = () => {
      setIsConnected(false)
      console.log('[NOMOS42] WebSocket déconnecté')
    }

    return () => ws.close()
  }, [options.url, options.onMessage])

  // ============================================
  // OPTION 2: API POLLING
  // ============================================
  const startPolling = useCallback(() => {
    if (!options.url) {
      setError('URL API requise')
      return
    }

    const interval = setInterval(async () => {
      try {
        const response = await fetch(options.url!)
        if (!response.ok) throw new Error('API Error')
        
        const data: LiveDataPayload[] = await response.json()
        
        const newMessages: Message[] = data.map((item, index) => ({
          id: `${Date.now()}-${index}`,
          agent: item.agent as Message['agent'],
          content: item.message,
          timestamp: item.timestamp,
          type: item.type
        }))
        
        setMessages(newMessages)
        setIsConnected(true)
        setError(null)
      } catch (err) {
        setError('Erreur API')
        setIsConnected(false)
        console.error('[NOMOS42] Polling error:', err)
      }
    }, options.pollingInterval || 2000)

    return () => clearInterval(interval)
  }, [options.url, options.pollingInterval])

  // ============================================
  // OPTION 3: FICHIER JSON LOCAL
  // ============================================
  const loadJsonFile = useCallback(async () => {
    try {
      const response = await fetch('/live-data.json')
      if (!response.ok) throw new Error('File not found')
      
      const data: LiveDataPayload[] = await response.json()
      
      const loadedMessages: Message[] = data.map((item, index) => ({
        id: `json-${index}`,
        agent: item.agent as Message['agent'],
        content: item.message,
        timestamp: item.timestamp,
        type: item.type
      }))
      
      setMessages(loadedMessages)
      setIsConnected(true)
    } catch (err) {
      setError('Fichier live-data.json non trouvé')
      console.error('[NOMOS42] JSON load error:', err)
    }
  }, [])

  // ============================================
  // OPTION 4: SERVER-SENT EVENTS
  // ============================================
  const connectEventSource = useCallback(() => {
    if (!options.url) {
      setError('URL EventSource requise')
      return
    }

    const es = new EventSource(options.url)

    es.onopen = () => {
      setIsConnected(true)
      setError(null)
    }

    es.onmessage = (event) => {
      try {
        const data: LiveDataPayload = JSON.parse(event.data)
        const message: Message = {
          id: Date.now().toString(),
          agent: data.agent as Message['agent'],
          content: data.message,
          timestamp: data.timestamp,
          type: data.type
        }
        setMessages(prev => [...prev, message])
        options.onMessage?.(message)
      } catch (err) {
        console.error('[NOMOS42] SSE parsing error:', err)
      }
    }

    es.onerror = () => {
      setError('Erreur EventSource')
      setIsConnected(false)
    }

    return () => es.close()
  }, [options.url, options.onMessage])

  // ============================================
  // INITIALISATION SELON LE MODE
  // ============================================
  useEffect(() => {
    let cleanup: (() => void) | undefined

    switch (options.mode) {
      case 'websocket':
        cleanup = connectWebSocket()
        break
      case 'polling':
        cleanup = startPolling()
        break
      case 'json':
        loadJsonFile()
        break
      case 'eventsource':
        cleanup = connectEventSource()
        break
    }

    return () => cleanup?.()
  }, [options.mode, connectWebSocket, startPolling, loadJsonFile, connectEventSource])

  return {
    messages,
    isConnected,
    error,
    // Fonction pour ajouter manuellement un message
    addMessage: (message: Omit<Message, 'id'>) => {
      const newMessage = { ...message, id: Date.now().toString() }
      setMessages(prev => [...prev, newMessage])
    },
    // Fonction pour vider les messages
    clearMessages: () => setMessages([])
  }
}

// ============================================
// EXEMPLE D'UTILISATION:
// ============================================
// 
// import { useLiveData } from './hooks/useLiveData'
//
// function App() {
//   const { messages, isConnected } = useLiveData({
//     url: 'wss://nomos42-worker.hf.space/ws',
//     mode: 'websocket',
//     onMessage: (msg) => console.log('Nouveau message:', msg)
//   })
//   
//   return (
//     <div>
//       {isConnected ? 'Connecté' : 'Déconnecté'}
//       {messages.map(msg => <p key={msg.id}>{msg.content}</p>)}
//     </div>
//   )
// }
//
// ============================================
