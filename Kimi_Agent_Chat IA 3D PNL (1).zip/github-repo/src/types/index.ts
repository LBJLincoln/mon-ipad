// Types pour NOMOS42 PNL 3D

export interface Message {
  id: string
  agent: 'N.O.S' | 'ADEMO' | 'MONK'
  content: string
  timestamp: Date | string
  type: 'status' | 'analysis' | 'action' | 'discovery' | 'error'
}

export interface Agent {
  id: string
  name: 'N.O.S' | 'ADEMO' | 'MONK'
  role: string
  image: string
  color: string
  position: [number, number, number]
}

export interface Metrics {
  brier: string
  accuracy: string
  roi: string
  features: string
  generation: string
  population: string
  cycles?: string
  discovered?: string
}

export interface LiveDataPayload {
  agent: string
  message: string
  type: Message['type']
  timestamp: string
  metrics?: Partial<Metrics>
}
