# n8n RAG Workflows -- Production Templates

11 production-tested n8n workflows for building multi-pipeline RAG systems.

## Workflows Included

| File | Description |
|------|-------------|
| `standard.json` | Standard RAG pipeline (vector search + LLM synthesis) |
| `graph.json` | Graph RAG pipeline (Neo4j knowledge graph + vector) |
| `quantitative.json` | Quantitative RAG (SQL generation + numerical analysis) |
| `orchestrator.json` | Meta-orchestrator (routes queries to best pipeline) |
| `ingestion.json` | Document ingestion (chunking, embedding, indexing) |
| `enrichment.json` | Document enrichment (entity extraction, graph building) |
| `benchmark.json` | Evaluation harness (automated testing) |
| `benchmark-dataset-ingestion.json` | SOTA benchmark dataset loader (18 datasets) |
| `pme-gateway.json` | Multi-tenant API gateway |
| `project-chatbot-v3.json` | Chatbot frontend integration |
| `project-chatbot-llm.json` | Chatbot LLM configuration |

## How to Import

1. Open your n8n instance
2. Go to **Workflows** > **Import from File**
3. Select any `.json` file from the `workflows/` folder
4. Update credentials:
   - Create your own OpenRouter, Pinecone, Neo4j, and Supabase credentials
   - Replace `REDACTED` values with your API keys
5. Update webhook paths if needed
6. Activate the workflow

## Architecture

```
User Query
    |
    v
[Orchestrator] --> routes to best pipeline
    |
    +---> [Standard RAG]     -- vector similarity search
    +---> [Graph RAG]        -- knowledge graph traversal
    +---> [Quantitative RAG] -- SQL + numerical reasoning
    |
    v
[Response + Citations]
```

## Prerequisites

- n8n v1.60+ (self-hosted or cloud)
- OpenRouter API key (or any OpenAI-compatible LLM)
- Pinecone account (vector database)
- Neo4j Aura (for Graph RAG)
- PostgreSQL/Supabase (for Quantitative RAG)

## Notes

- All credential values have been replaced with `REDACTED`
- Webhook paths may need updating for your deployment
- Batch sizes are tuned for free-tier API limits

---
(c) Nomos AI. All rights reserved.
