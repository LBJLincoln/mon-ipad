# Claude Code Skills -- 17 Production Commands

Custom slash commands for Claude Code that automate RAG engineering workflows.

## Skills Included

| Command | Description |
|---------|-------------|
| `/session-start` | Initialize work session (load state, check infra) |
| `/session-end` | End session (commit, push, update state) |
| `/eval` | Run evaluation suite on RAG pipelines |
| `/status-check` | Check all infrastructure health |
| `/sync-directives` | Push directives to satellite repos |
| `/ingest-check` | Verify data ingestion status |
| `/monitor` | Real-time pipeline monitoring |
| `/self-heal` | Auto-diagnose and fix common issues |
| `/improve` | Suggest and implement improvements |
| `/progress-10pct` | Focus on highest-impact 10% improvement |
| `/regression-check` | Detect performance regressions |
| `/metrics-update` | Update dashboard metrics |
| `/fix-catalog` | Browse and apply known fixes |
| `/research-update` | Update SOTA research notes |
| `/cross-repo-sync` | Sync changes across repositories |
| `/website-audit` | Audit website for issues |
| `/video-brief` | Generate video content briefs |

## How to Install

```bash
# Copy all skills to your project's Claude Code commands directory
mkdir -p /your-project/.claude/commands/
cp commands/*.md /your-project/.claude/commands/

# Skills are now available as /command-name in Claude Code
```

## Customization

Each skill is a Markdown file with structured instructions. Edit them to match your:
- Repository structure
- Infrastructure endpoints
- Evaluation criteria
- Team workflows

## Requirements

- Claude Code CLI (v2.1+)
- A project with `.claude/` directory

---
(c) Nomos AI. All rights reserved.
