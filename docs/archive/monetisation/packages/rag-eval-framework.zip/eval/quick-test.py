#!/usr/bin/env python3
"""
Quick Test — Smoke test RAG endpoints after workflow modifications.

Runs 3-5 known-good questions per pipeline and records results
in data.json quick_tests[]. Used for fast validation before full eval.

Usage:
  python quick-test.py                                    # All pipelines, 3 questions
  python quick-test.py --pipelines standard,graph         # Specific pipelines
  python quick-test.py --questions 5                      # 5 questions per pipeline
"""

import json
import os
import sys
import time
from datetime import datetime
from urllib import request, error
from importlib.machinery import SourceFileLoader

REPO_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
EVAL_DIR = os.path.dirname(os.path.abspath(__file__))
N8N_HOST = os.environ.get("N8N_HOST", "https://YOUR-N8N-HOST.example.com")

# Multi-Space support: comma-separated URLs per pipeline or global
N8N_ALL_HOSTS = [h.strip() for h in os.environ.get("N8N_ALL_HOSTS", N8N_HOST).split(",") if h.strip()]
_rr_counters = {}

def _get_hosts_for_pipeline(pipeline):
    """Get list of hosts for a pipeline (from env or global)."""
    env_key = f"N8N_HOST_{pipeline.upper()}"
    hosts_str = os.environ.get(env_key, "")
    if hosts_str and "<" not in hosts_str:
        return [h.strip() for h in hosts_str.split(",") if h.strip()]
    return N8N_ALL_HOSTS

def _rr_endpoint(pipeline, webhook_path):
    """Round-robin across healthy hosts for a pipeline."""
    hosts = _get_hosts_for_pipeline(pipeline)
    if not hosts:
        return f"{N8N_HOST}{webhook_path}"
    idx = _rr_counters.get(pipeline, 0)
    _rr_counters[pipeline] = idx + 1
    host = hosts[idx % len(hosts)]
    return f"{host}{webhook_path}"

def _check_host_health(host, timeout=8):
    """Quick health check on a host. Returns True if alive."""
    try:
        req = request.Request(f"{host}/healthz", method="GET")
        with request.urlopen(req, timeout=timeout) as resp:
            return resp.status == 200
    except Exception:
        return False

# Guard: block accidental use of VM n8n for evals
def _check_n8n_host():
    import re
    if re.search(r'localhost|127\.0\.0\.1|34\.136\.180\.66', N8N_HOST):
        if "--allow-local" not in sys.argv:
            print(f"FATAL: N8N_HOST points to local/VM ({N8N_HOST}).")
            print("Evals MUST run on HF Space. Set N8N_HOST or pass --allow-local.")
            sys.exit(1)
_check_n8n_host()

# Load writer (optional — only for dashboard logging)
try:
    writer = SourceFileLoader("w", os.path.join(EVAL_DIR, "live-writer.py")).load_module()
except FileNotFoundError:
    class _NullWriter:
        def record_quick_test(self, **kw): pass
    writer = _NullWriter()

WEBHOOK_PATHS = {
    "standard":     "/webhook/rag-multi-index-v3",
    "graph":        "/webhook/ff622742-6d71-4e91-af71-b5c666088717",
    "quantitative": "/webhook/3e0f8010-39e0-4bca-9d19-35e5094391a9",
    "orchestrator": "/webhook/92217bb8-ffc8-459a-8331-3f553812c3d0",
}

# Backward compat: RAG_ENDPOINTS uses default host
RAG_ENDPOINTS = {k: f"{N8N_HOST}{v}" for k, v in WEBHOOK_PATHS.items()}

# Known-good test questions (questions that should always pass)
SMOKE_QUESTIONS = {
    "standard": [
        # Mix of general knowledge (tests LLM) + domain-specific (tests RAG retrieval)
        {"query": "What is the capital of Japan?", "expected_contains": "Tokyo"},
        {"query": "Who painted the Mona Lisa?", "expected_contains": "Vinci"},
        {"query": "What is machine learning?", "expected_contains": "algorithm"},
        {"query": "What is intraocular pressure?", "expected_contains": "eye"},
        {"query": "What is PCR used for in molecular biology?", "expected_contains": "amplif"},
    ],
    "graph": [
        # Entity relationship questions (tests Neo4j graph traversal)
        {"query": "What did Marie Curie win Nobel Prizes for?", "expected_contains": "Physics"},
        {"query": "What did Alexander Fleming discover?", "expected_contains": "penicillin"},
        {"query": "Who founded Microsoft?", "expected_contains": "Gates"},
        {"query": "What is the WHO?", "expected_contains": "Health"},
        {"query": "What disease is caused by mosquitoes?", "expected_contains": "malaria"},
    ],
    "quantitative": [
        # Financial questions with verifiable expected answers from Supabase
        {"query": "What was the yearly amortization rate related to the trademarks?", "expected_contains": "8"},
        {"query": "What was the decrease in the Other expense, net in 2018?", "expected_contains": "4"},
        {"query": "What was TechVision Inc's total revenue in fiscal year 2023?", "expected_contains": ""},
        {"query": "What was GreenEnergy Corp's total revenue in 2023?", "expected_contains": ""},
        {"query": "What was HealthPlus Labs' net income in 2022?", "expected_contains": ""},
    ],
    "orchestrator": [
        # ON HOLD — orchestrator webhook returns 404
        {"query": "What is the capital of Japan?", "expected_contains": "Tokyo"},
        {"query": "Who painted the Mona Lisa?", "expected_contains": "Vinci"},
        {"query": "What is the largest ocean?", "expected_contains": "Pacific"},
    ],
}


def normalize_for_match(text):
    """Normalize text for fuzzy matching — strip formatting from numbers etc."""
    import re
    # Remove commas from numbers (6,745 → 6745), dollar signs, percent signs
    normalized = re.sub(r'(\d),(\d)', r'\1\2', text)
    normalized = normalized.replace('$', '').replace('%', '')
    return normalized.lower()


def call_endpoint(endpoint, query, timeout=60, max_retries=3):
    """Call a RAG endpoint with exponential backoff on 503/error."""
    payload = json.dumps({
        "query": query,
        "tenant_id": "benchmark",
        "top_k": 10,
        "include_sources": True,
        "benchmark_mode": True,
    }).encode()
    headers = {"Content-Type": "application/json"}

    for attempt in range(max_retries):
        try:
            req = request.Request(endpoint, data=payload, headers=headers, method="POST")
            start = time.time()
            with request.urlopen(req, timeout=timeout) as resp:
                raw = resp.read().decode()
                latency = int((time.time() - start) * 1000)
                if raw and raw.strip():
                    data = json.loads(raw)
                    if isinstance(data, list):
                        data = data[0] if data else {}
                    answer = ""
                    for key in ["response", "answer", "result", "interpretation", "final_response"]:
                        if key in data and data[key]:
                            answer = str(data[key])
                            break
                    return {"status": "ok", "latency_ms": latency, "answer": answer, "error": None}
                return {"status": "empty", "latency_ms": latency, "answer": "", "error": "Empty response"}
        except error.HTTPError as e:
            if e.code == 503 and attempt < max_retries - 1:
                wait = 3 * (2 ** attempt)  # 3s, 6s, 12s
                print(f"    503 on attempt {attempt+1} — retry in {wait}s")
                time.sleep(wait)
                continue
            return {"status": "error", "latency_ms": 0, "answer": "", "error": f"HTTP {e.code}: {str(e)[:150]}"}
        except Exception as e:
            if attempt < max_retries - 1:
                time.sleep(3 * (2 ** attempt))
                continue
            return {"status": "error", "latency_ms": 0, "answer": "", "error": str(e)[:200]}
    return {"status": "error", "latency_ms": 0, "answer": "", "error": "Max retries exceeded"}


def run_quick_tests(pipelines, max_questions=3, trigger="manual"):
    """Run quick smoke tests for specified pipelines."""
    results = {}

    for pipe in pipelines:
        webhook_path = WEBHOOK_PATHS.get(pipe)
        questions = SMOKE_QUESTIONS.get(pipe, [])[:max_questions]
        if not webhook_path or not questions:
            continue

        print(f"\n  Quick test: {pipe.upper()} ({len(questions)} questions)")
        pipe_results = []

        for i, q in enumerate(questions):
            # Use generous timeouts — LLM calls via free models can be slow (429 retries)
            pipe_timeout = 300 if pipe in ("orchestrator", "quantitative") else 90
            # For quantitative: 1 retry max (not 3) — prevents cascading stale n8n executions
            pipe_max_retries = 1 if pipe == "quantitative" else 3
            if i > 0:
                time.sleep(3)  # 3s between questions — prevents n8n 503 (LIMIT=2)
            endpoint = _rr_endpoint(pipe, webhook_path)
            resp = call_endpoint(endpoint, q["query"], timeout=pipe_timeout, max_retries=pipe_max_retries)
            expected = q.get("expected_contains", "")
            passed = False

            if resp["status"] == "ok" and resp["answer"]:
                if expected:
                    # Normalize both sides to handle number formatting (6,745 vs 6745)
                    norm_answer = normalize_for_match(resp["answer"])
                    norm_expected = normalize_for_match(expected)
                    if norm_expected in norm_answer:
                        passed = True
                elif not expected and len(resp["answer"]) > 0:
                    passed = True  # No expected = just check non-empty response

            status = "pass" if passed else ("error" if resp["error"] else "fail")
            symbol = "[+]" if passed else "[-]"
            print(f"    {symbol} {q['query'][:60]} | {resp['latency_ms']}ms | {status}")
            if resp["error"]:
                print(f"        ERR: {resp['error'][:100]}")
            else:
                print(f"        A: {resp['answer'][:100]}")

            # Record to dashboard
            writer.record_quick_test(
                pipeline=pipe,
                query=q["query"],
                status=status,
                latency_ms=resp["latency_ms"],
                response_preview=resp["answer"][:200],
                trigger=trigger,
                error=resp["error"],
            )

            pipe_results.append({"query": q["query"], "status": status, "latency_ms": resp["latency_ms"]})

        pass_count = sum(1 for r in pipe_results if r["status"] == "pass")
        total = len(pipe_results)
        print(f"    Result: {pass_count}/{total} passed")
        results[pipe] = {"passed": pass_count, "total": total, "results": pipe_results}

    return results


def main():
    import argparse
    parser = argparse.ArgumentParser(description="Quick endpoint smoke tests")
    parser.add_argument("--pipelines", type=str, default="standard,graph,quantitative")
    parser.add_argument("--questions", type=int, default=3)
    parser.add_argument("--trigger", type=str, default="manual")
    parser.add_argument("--allow-local", action="store_true", help="Allow localhost/VM n8n (for CI)")
    args = parser.parse_args()

    pipelines = [p.strip() for p in args.pipelines.split(",")]
    print("=" * 50)
    print("  QUICK ENDPOINT SMOKE TEST")
    print(f"  Pipelines: {', '.join(pipelines)}")
    print(f"  Questions per pipeline: {args.questions}")
    print(f"  Hosts: {len(N8N_ALL_HOSTS)} Space(s)")
    for h in N8N_ALL_HOSTS:
        print(f"    - {h}")
    print("=" * 50)

    results = run_quick_tests(pipelines, max_questions=args.questions, trigger=args.trigger)

    print("\n" + "=" * 50)
    print("  SUMMARY")
    print("=" * 50)
    all_pass = True
    for pipe, info in results.items():
        status = "PASS" if info["passed"] == info["total"] else "FAIL"
        if status == "FAIL":
            all_pass = False
        print(f"  {pipe}: {info['passed']}/{info['total']} {status}")

    if not all_pass:
        print("\n  WARNING: Some endpoints are failing. Check before running full eval.")
        sys.exit(1)
    else:
        print("\n  All endpoints healthy.")


if __name__ == "__main__":
    main()
