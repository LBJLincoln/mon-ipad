# RAG Evaluation Framework

Production evaluation framework for RAG pipelines. Tested on 61,000+ questions across 18 SOTA benchmarks.

## Scripts

| Script | Description |
|--------|-------------|
| `quick-test.py` | Quick smoke test (5 questions per pipeline) |
| `run-eval.py` | Full evaluation run with scoring |
| `run-eval-parallel.py` | Parallel evaluation across multiple n8n instances |
| `node-analyzer.py` | Deep analysis of n8n execution nodes |
| `golden-check.py` | Compare results against golden reference set |
| `iterative-eval.py` | Iterative improvement evaluation loop |
| `generate_status.py` | Generate status dashboard data |
| `live-writer.py` | Write evaluation results to databases |
| `sector-eval.py` | Sector-specific evaluation (finance, legal, etc.) |
| `phase_gates.py` | Phase gate validation (pass/fail criteria) |
| `progress_callback.py` | Progress reporting callbacks |
| `tz_utils.py` | Timezone utilities |

## Quick Start

```bash
# Set environment variables
export N8N_HOST="https://your-n8n-instance.example.com"
export PINECONE_API_KEY="your-key"
export SUPABASE_PASSWORD="your-password"

# Run quick test
python3 eval/quick-test.py --questions 5 --pipeline standard

# Run full evaluation
python3 eval/run-eval.py --dataset phase-3 --types standard,graph,quant

# Parallel evaluation (requires multiple n8n instances)
python3 eval/run-eval-parallel.py --dataset phase-3 --types standard --reset --label "v3.4-test"

# Analyze a specific execution
python3 eval/node-analyzer.py --execution-id 12345
```

## Scoring

The framework uses multi-signal scoring:
- **Exact match** -- normalized string comparison
- **Fuzzy match** -- token overlap with threshold
- **Semantic match** -- embedding similarity (optional)
- **LLM grading** -- GPT-based correctness assessment (optional)

## Configuration

All scripts read configuration from environment variables (no hardcoded keys).
Required variables:
- `N8N_HOST` -- Your n8n instance URL
- `PINECONE_API_KEY` -- For vector search evaluation
- `SUPABASE_PASSWORD` -- For database queries
- `NEO4J_PASSWORD` -- For graph pipeline evaluation

## Requirements

```
python3 >= 3.9
requests
psycopg2-binary  # optional, for database evaluation
```

---
(c) Nomos AI. All rights reserved.
